const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');

const client = new Client({
    authStrategy: new LocalAuth(),
});

client.on('qr', (qr) => {
    console.log('Scan this QR code with your WhatsApp app:');
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('✅ WhatsApp bot is ready and connected!');
});

client.on('message', async message => {
    try {
        // Only respond to group messages
        if (!message.isGroupMsg) return;

        const chat = await message.getChat();
        const sender = await message.getContact();

        // Check if sender is admin
        let isAdmin = false;
        if (chat.isGroup) {
            const participants = chat.participants;
            const senderParticipant = participants.find(p => p.id._serialized === sender.id._serialized);
            isAdmin = senderParticipant && senderParticipant.isAdmin;
        }

        // Command: /announce <text>
        if (message.body.startsWith('/announce ')) {
            if (!isAdmin) {
                return message.reply('❌ Only group admins can send announcements.');
            }
            const announcement = message.body.replace('/announce ', '').trim();
            if (!announcement) {
                return message.reply('⚠️ Please provide the announcement text.');
            }
            await chat.sendMessage(`📢 *Announcement by ${sender.pushname || sender.number}:*\n${announcement}`);
            return;
        }

        // Command: /help
        if (message.body === '/help') {
            return message.reply(
                `*Group Management Bot*\n` +
                `Commands:\n` +
                `• /announce <text> — Send group announcement (admins only)\n` +
                `• /help — List commands`
            );
        }

    } catch (err) {
        console.error('Error handling message:', err);
    }
});

client.initialize();